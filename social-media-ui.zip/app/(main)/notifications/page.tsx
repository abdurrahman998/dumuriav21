import type { Metadata } from "next"
import { NotificationList } from "@/components/notifications/notification-list"

export const metadata: Metadata = {
  title: "Notifications | SocialSphere",
  description: "Your activity notifications on SocialSphere",
}

export default function NotificationsPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Notifications</h1>
      <NotificationList />
    </div>
  )
}

