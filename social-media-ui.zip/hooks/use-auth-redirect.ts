"use client"

import { useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { useAuth } from "@/lib/auth"

export function useAuthRedirect() {
  const { status, user } = useAuth()
  const router = useRouter()
  const pathname = usePathname()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (status === "loading") {
      setIsLoading(true)
      return
    }

    setIsLoading(false)

    if (status === "unauthenticated") {
      // Store the current path to redirect back after login
      sessionStorage.setItem("redirectAfterLogin", pathname)
      router.push("/login")
      setIsAuthenticated(false)
      return
    }

    setIsAuthenticated(true)
  }, [status, router, pathname, user])

  return { isAuthenticated, isLoading }
}

