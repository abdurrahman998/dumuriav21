import type { Metadata } from "next"
import { redirect } from "next/navigation"
import { EditProfileForm } from "@/components/user/edit-profile-form"
import { getUserProfile } from "@/lib/data"

export const metadata: Metadata = {
  title: "Edit Profile | SocialSphere",
  description: "Edit your SocialSphere profile",
}

export default function EditProfilePage() {
  // In a real app, we would check if the user is authenticated
  // For demo purposes, we'll assume the current user is "johndoe"
  const currentUsername = "johndoe"
  const user = getUserProfile(currentUsername)

  if (!user) {
    redirect("/feed")
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Edit Profile</h1>
        <p className="text-muted-foreground">Update your profile information and settings.</p>
      </div>
      <EditProfileForm user={user} />
    </div>
  )
}

