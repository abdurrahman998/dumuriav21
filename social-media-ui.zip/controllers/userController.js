import User from "../models/User.js"
import { ApiError } from "../utils/ApiError.js"
import { updateUserSchema } from "../utils/validators.js"
import { processImage, getFileUrl, deleteFile } from "../utils/fileUpload.js"
import path from "path"

// Get current user
export const getCurrentUser = async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .select("-__v")
      .populate("followers", "username name profilePicture")
      .populate("following", "username name profilePicture")

    res.status(200).json({
      success: true,
      data: user,
    })
  } catch (error) {
    throw new ApiError(500, "Error fetching user profile", [error.message])
  }
}

// Get user by ID
export const getUserById = async (req, res) => {
  const { id } = req.params

  try {
    const user = await User.findById(id)
      .select("-__v")
      .populate("followers", "username name profilePicture")
      .populate("following", "username name profilePicture")

    if (!user) {
      throw new ApiError(404, "User not found")
    }

    // Check if user is blocked
    if (req.user && req.user.blockedUsers.includes(id)) {
      throw new ApiError(403, "You have blocked this user")
    }

    // Check if current user is blocked by this user
    if (req.user && user.blockedUsers.includes(req.user._id)) {
      throw new ApiError(403, "You have been blocked by this user")
    }

    res.status(200).json({
      success: true,
      data: user,
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error fetching user", [error.message])
  }
}

// Get user by username
export const getUserByUsername = async (req, res) => {
  const { username } = req.params

  try {
    const user = await User.findOne({ username })
      .select("-__v")
      .populate("followers", "username name profilePicture")
      .populate("following", "username name profilePicture")

    if (!user) {
      throw new ApiError(404, "User not found")
    }

    // Check if user is blocked (if authenticated)
    if (req.user && req.user.blockedUsers.includes(user._id)) {
      throw new ApiError(403, "You have blocked this user")
    }

    // Check if current user is blocked by this user
    if (req.user && user.blockedUsers.includes(req.user._id)) {
      throw new ApiError(403, "You have been blocked by this user")
    }

    res.status(200).json({
      success: true,
      data: user,
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error fetching user", [error.message])
  }
}

// Update user
export const updateUser = async (req, res) => {
  // Validate request body
  const { error, value } = updateUserSchema.validate(req.body)
  if (error) {
    throw new ApiError(
      400,
      "Validation Error",
      error.details.map((d) => d.message),
    )
  }

  try {
    const user = await User.findById(req.user._id)

    // Update user fields
    Object.keys(value).forEach((key) => {
      if (key !== "profilePicture" && key !== "coverPhoto") {
        user[key] = value[key]
      }
    })

    // Handle profile picture upload
    if (req.files && req.files.profilePicture) {
      const file = req.files.profilePicture[0]

      // Delete old profile picture if exists
      if (user.profilePicture) {
        const urlParts = new URL(user.profilePicture)
        const filePath = path.join(process.cwd(), urlParts.pathname)
        deleteFile(filePath)
      }

      // Process and save new profile picture
      await processImage(file.path, { width: 400, height: 400 })
      user.profilePicture = getFileUrl(file.path)
    }

    // Handle cover photo upload
    if (req.files && req.files.coverPhoto) {
      const file = req.files.coverPhoto[0]

      // Delete old cover photo if exists
      if (user.coverPhoto) {
        const urlParts = new URL(user.coverPhoto)
        const filePath = path.join(process.cwd(), urlParts.pathname)
        deleteFile(filePath)
      }

      // Process and save new cover photo
      await processImage(file.path, { width: 1200, height: 400 })
      user.coverPhoto = getFileUrl(file.path)
    }

    await user.save()

    res.status(200).json({
      success: true,
      message: "User updated successfully",
      data: user,
    })
  } catch (error) {
    // Delete uploaded files if update fails
    if (req.files) {
      if (req.files.profilePicture) {
        deleteFile(req.files.profilePicture[0].path)
      }
      if (req.files.coverPhoto) {
        deleteFile(req.files.coverPhoto[0].path)
      }
    }

    throw new ApiError(500, "Error updating user", [error.message])
  }
}

// Delete user
export const deleteUser = async (req, res) => {
  try {
    const user = await User.findById(req.user._id)

    // Delete profile picture and cover photo
    if (user.profilePicture) {
      const urlParts = new URL(user.profilePicture)
      const filePath = path.join(process.cwd(), urlParts.pathname)
      deleteFile(filePath)
    }

    if (user.coverPhoto) {
      const urlParts = new URL(user.coverPhoto)
      const filePath = path.join(process.cwd(), urlParts.pathname)
      deleteFile(filePath)
    }

    // Delete user
    await User.findByIdAndDelete(req.user._id)

    res.status(200).json({
      success: true,
      message: "User deleted successfully",
    })
  } catch (error) {
    throw new ApiError(500, "Error deleting user", [error.message])
  }
}

// Follow user
export const followUser = async (req, res) => {
  const { id } = req.params

  if (id === req.user._id.toString()) {
    throw new ApiError(400, "You cannot follow yourself")
  }

  try {
    const userToFollow = await User.findById(id)

    if (!userToFollow) {
      throw new ApiError(404, "User not found")
    }

    const currentUser = await User.findById(req.user._id)

    // Check if already following
    if (currentUser.following.includes(id)) {
      return res.status(200).json({
        success: true,
        message: "You are already following this user",
      })
    }

    // Check if user is blocked
    if (currentUser.blockedUsers.includes(id) || userToFollow.blockedUsers.includes(req.user._id)) {
      throw new ApiError(403, "Cannot follow this user")
    }

    // Add to following
    currentUser.following.push(id)
    await currentUser.save()

    // Add to followers
    userToFollow.followers.push(req.user._id)
    await userToFollow.save()

    // Create notification (in a real app)

    res.status(200).json({
      success: true,
      message: "User followed successfully",
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error following user", [error.message])
  }
}

// Unfollow user
export const unfollowUser = async (req, res) => {
  const { id } = req.params

  if (id === req.user._id.toString()) {
    throw new ApiError(400, "You cannot unfollow yourself")
  }

  try {
    const userToUnfollow = await User.findById(id)

    if (!userToUnfollow) {
      throw new ApiError(404, "User not found")
    }

    const currentUser = await User.findById(req.user._id)

    // Check if not following
    if (!currentUser.following.includes(id)) {
      return res.status(200).json({
        success: true,
        message: "You are not following this user",
      })
    }

    // Remove from following
    currentUser.following = currentUser.following.filter((userId) => userId.toString() !== id)
    await currentUser.save()

    // Remove from followers
    userToUnfollow.followers = userToUnfollow.followers.filter(
      (userId) => userId.toString() !== req.user._id.toString(),
    )
    await userToUnfollow.save()

    res.status(200).json({
      success: true,
      message: "User unfollowed successfully",
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error unfollowing user", [error.message])
  }
}

// Get followers
export const getFollowers = async (req, res) => {
  const { id } = req.params
  const { page = 1, limit = 10 } = req.query
  const skip = (page - 1) * limit

  try {
    const user = await User.findById(id)

    if (!user) {
      throw new ApiError(404, "User not found")
    }

    // Check if user is blocked
    if (req.user && (req.user.blockedUsers.includes(id) || user.blockedUsers.includes(req.user._id))) {
      throw new ApiError(403, "Cannot view followers")
    }

    // Get followers with pagination
    const followers = await User.find({ _id: { $in: user.followers } })
      .select("username name profilePicture")
      .skip(skip)
      .limit(Number.parseInt(limit))

    // Get total count for pagination
    const total = user.followers.length

    res.status(200).json({
      success: true,
      data: {
        followers,
        pagination: {
          total,
          page: Number.parseInt(page),
          pages: Math.ceil(total / limit),
        },
      },
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error fetching followers", [error.message])
  }
}

// Get following
export const getFollowing = async (req, res) => {
  const { id } = req.params
  const { page = 1, limit = 10 } = req.query
  const skip = (page - 1) * limit

  try {
    const user = await User.findById(id)

    if (!user) {
      throw new ApiError(404, "User not found")
    }

    // Check if user is blocked
    if (req.user && (req.user.blockedUsers.includes(id) || user.blockedUsers.includes(req.user._id))) {
      throw new ApiError(403, "Cannot view following")
    }

    // Get following with pagination
    const following = await User.find({ _id: { $in: user.following } })
      .select("username name profilePicture")
      .skip(skip)
      .limit(Number.parseInt(limit))

    // Get total count for pagination
    const total = user.following.length

    res.status(200).json({
      success: true,
      data: {
        following,
        pagination: {
          total,
          page: Number.parseInt(page),
          pages: Math.ceil(total / limit),
        },
      },
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error fetching following", [error.message])
  }
}

// Block user
export const blockUser = async (req, res) => {
  const { id } = req.params

  if (id === req.user._id.toString()) {
    throw new ApiError(400, "You cannot block yourself")
  }

  try {
    const userToBlock = await User.findById(id)

    if (!userToBlock) {
      throw new ApiError(404, "User not found")
    }

    const currentUser = await User.findById(req.user._id)

    // Check if already blocked
    if (currentUser.blockedUsers.includes(id)) {
      return res.status(200).json({
        success: true,
        message: "User is already blocked",
      })
    }

    // Add to blocked users
    currentUser.blockedUsers.push(id)

    // Remove from following/followers if applicable
    if (currentUser.following.includes(id)) {
      currentUser.following = currentUser.following.filter((userId) => userId.toString() !== id)

      userToBlock.followers = userToBlock.followers.filter((userId) => userId.toString() !== req.user._id.toString())
      await userToBlock.save()
    }

    if (currentUser.followers.includes(id)) {
      currentUser.followers = currentUser.followers.filter((userId) => userId.toString() !== id)

      userToBlock.following = userToBlock.following.filter((userId) => userId.toString() !== req.user._id.toString())
      await userToBlock.save()
    }

    await currentUser.save()

    res.status(200).json({
      success: true,
      message: "User blocked successfully",
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error blocking user", [error.message])
  }
}

// Unblock user
export const unblockUser = async (req, res) => {
  const { id } = req.params

  try {
    const userToUnblock = await User.findById(id)

    if (!userToUnblock) {
      throw new ApiError(404, "User not found")
    }

    const currentUser = await User.findById(req.user._id)

    // Check if not blocked
    if (!currentUser.blockedUsers.includes(id)) {
      return res.status(200).json({
        success: true,
        message: "User is not blocked",
      })
    }

    // Remove from blocked users
    currentUser.blockedUsers = currentUser.blockedUsers.filter((userId) => userId.toString() !== id)

    await currentUser.save()

    res.status(200).json({
      success: true,
      message: "User unblocked successfully",
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error unblocking user", [error.message])
  }
}

// Get blocked users
export const getBlockedUsers = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).populate("blockedUsers", "username name profilePicture")

    res.status(200).json({
      success: true,
      data: user.blockedUsers,
    })
  } catch (error) {
    throw new ApiError(500, "Error fetching blocked users", [error.message])
  }
}

// Search users
export const searchUsers = async (req, res) => {
  const { q, page = 1, limit = 10 } = req.query
  const skip = (page - 1) * limit

  try {
    let query = {}

    if (q) {
      query = {
        $or: [{ username: { $regex: q, $options: "i" } }, { name: { $regex: q, $options: "i" } }],
      }
    }

    // Exclude blocked users if authenticated
    if (req.user) {
      query._id = { $nin: req.user.blockedUsers }
      query.blockedUsers = { $ne: req.user._id }
    }

    // Find users
    const users = await User.find(query)
      .select("username name profilePicture bio")
      .skip(skip)
      .limit(Number.parseInt(limit))

    // Get total count for pagination
    const total = await User.countDocuments(query)

    res.status(200).json({
      success: true,
      data: {
        users,
        pagination: {
          total,
          page: Number.parseInt(page),
          pages: Math.ceil(total / limit),
        },
      },
    })
  } catch (error) {
    throw new ApiError(500, "Error searching users", [error.message])
  }
}

// Update user role (admin only)
export const updateUserRole = async (req, res) => {
  const { id } = req.params
  const { role } = req.body

  if (!role || !["user", "moderator", "admin"].includes(role)) {
    throw new ApiError(400, "Valid role is required")
  }

  try {
    const user = await User.findById(id)

    if (!user) {
      throw new ApiError(404, "User not found")
    }

    // Update role
    user.role = role
    await user.save()

    res.status(200).json({
      success: true,
      message: "User role updated successfully",
      data: {
        id: user._id,
        username: user.username,
        role: user.role,
      },
    })
  } catch (error) {
    if (error instanceof ApiError) {
      throw error
    }
    throw new ApiError(500, "Error updating user role", [error.message])
  }
}

// Get suggested users
export const getSuggestedUsers = async (req, res) => {
  try {
    const currentUser = await User.findById(req.user._id)

    // Get users that the current user is not following
    // and exclude blocked users
    const suggestedUsers = await User.find({
      _id: {
        $nin: [...currentUser.following, req.user._id, ...currentUser.blockedUsers],
      },
      blockedUsers: { $ne: req.user._id },
    })
      .select("username name profilePicture bio")
      .limit(10)

    res.status(200).json({
      success: true,
      data: suggestedUsers,
    })
  } catch (error) {
    throw new ApiError(500, "Error fetching suggested users", [error.message])
  }
}

