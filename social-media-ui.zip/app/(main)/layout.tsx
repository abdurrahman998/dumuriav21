import type React from "react"
import { Sidebar } from "@/components/sidebar"
import { MobileNav } from "@/components/mobile-nav"
import { ProtectedRoute } from "@/components/auth/protected-route"

export default function MainLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <ProtectedRoute>
      <div className="flex min-h-screen">
        <Sidebar className="hidden md:flex" />
        <div className="flex-1">
          <MobileNav className="md:hidden" />
          <main className="container mx-auto px-4 py-6 md:px-6 md:py-8">{children}</main>
        </div>
      </div>
    </ProtectedRoute>
  )
}

