"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { User, FileText, Hash, Users, Calendar, Clock } from "lucide-react"
import { cn } from "@/lib/utils"

interface SearchFiltersProps {
  activeCategory: string
  onCategoryChange: (category: string) => void
}

export function SearchFilters({ activeCategory, onCategoryChange }: SearchFiltersProps) {
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Categories</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <Button
            variant="ghost"
            className={cn("w-full justify-start", activeCategory === "all" && "bg-accent text-accent-foreground")}
            onClick={() => onCategoryChange("all")}
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted">
              <User className="h-4 w-4" />
            </div>
            <span className="ml-2">All</span>
          </Button>
          <Button
            variant="ghost"
            className={cn("w-full justify-start", activeCategory === "users" && "bg-accent text-accent-foreground")}
            onClick={() => onCategoryChange("users")}
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted">
              <User className="h-4 w-4" />
            </div>
            <span className="ml-2">People</span>
          </Button>
          <Button
            variant="ghost"
            className={cn("w-full justify-start", activeCategory === "posts" && "bg-accent text-accent-foreground")}
            onClick={() => onCategoryChange("posts")}
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted">
              <FileText className="h-4 w-4" />
            </div>
            <span className="ml-2">Posts</span>
          </Button>
          <Button
            variant="ghost"
            className={cn("w-full justify-start", activeCategory === "hashtags" && "bg-accent text-accent-foreground")}
            onClick={() => onCategoryChange("hashtags")}
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted">
              <Hash className="h-4 w-4" />
            </div>
            <span className="ml-2">Hashtags</span>
          </Button>
          <Button
            variant="ghost"
            className={cn("w-full justify-start", activeCategory === "groups" && "bg-accent text-accent-foreground")}
            onClick={() => onCategoryChange("groups")}
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted">
              <Users className="h-4 w-4" />
            </div>
            <span className="ml-2">Groups</span>
          </Button>
          <Button
            variant="ghost"
            className={cn("w-full justify-start", activeCategory === "events" && "bg-accent text-accent-foreground")}
            onClick={() => onCategoryChange("events")}
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted">
              <Calendar className="h-4 w-4" />
            </div>
            <span className="ml-2">Events</span>
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Filters</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="date-range">Date Range</Label>
              <span className="text-xs text-muted-foreground">Any time</span>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" className="h-8 text-xs">
                <Clock className="mr-1 h-3 w-3" />
                Any time
              </Button>
              <Button variant="outline" size="sm" className="h-8 text-xs">
                Past 24h
              </Button>
              <Button variant="outline" size="sm" className="h-8 text-xs">
                Past week
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="engagement">Minimum Engagement</Label>
              <span className="text-xs text-muted-foreground">0+</span>
            </div>
            <Slider id="engagement" defaultValue={[0]} max={100} step={1} className="py-2" />
          </div>

          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Switch id="verified" />
              <Label htmlFor="verified">Verified accounts only</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Switch id="following" />
              <Label htmlFor="following">People you follow</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Switch id="media" />
              <Label htmlFor="media">Include media</Label>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

