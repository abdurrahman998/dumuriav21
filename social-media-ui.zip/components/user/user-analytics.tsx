"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Skeleton } from "@/components/ui/skeleton"
import { getUserAnalytics } from "@/lib/data"

export function UserAnalytics() {
  const [analytics, setAnalytics] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [timeframe, setTimeframe] = useState("week")

  useEffect(() => {
    const fetchAnalytics = async () => {
      setLoading(true)
      try {
        const data = await getUserAnalytics(timeframe)
        setAnalytics(data)
      } catch (error) {
        console.error("Error fetching analytics:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchAnalytics()
  }, [timeframe])

  if (loading) {
    return (
      <div className="space-y-4 pt-4">
        <Skeleton className="h-8 w-48" />
        <div className="grid gap-4 md:grid-cols-3">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-32 w-full" />
        </div>
        <Skeleton className="h-[300px] w-full" />
      </div>
    )
  }

  if (!analytics) {
    return (
      <div className="rounded-lg border p-8 text-center">
        <p className="text-muted-foreground">No analytics data available.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4 pt-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Profile Analytics</h3>
        <Tabs value={timeframe} onValueChange={setTimeframe}>
          <TabsList>
            <TabsTrigger value="week">Week</TabsTrigger>
            <TabsTrigger value="month">Month</TabsTrigger>
            <TabsTrigger value="year">Year</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Profile Views</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.profileViews.total}</div>
            <p className="text-xs text-muted-foreground">
              {analytics.profileViews.change > 0 ? "+" : ""}
              {analytics.profileViews.change}% from last {timeframe}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">New Followers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.newFollowers.total}</div>
            <p className="text-xs text-muted-foreground">
              {analytics.newFollowers.change > 0 ? "+" : ""}
              {analytics.newFollowers.change}% from last {timeframe}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Post Engagement</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.engagement.total}</div>
            <p className="text-xs text-muted-foreground">
              {analytics.engagement.change > 0 ? "+" : ""}
              {analytics.engagement.change}% from last {timeframe}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Engagement Over Time</CardTitle>
          <CardDescription>View your post engagement metrics over time</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <div>Likes</div>
              <div>Comments</div>
              <div>Shares</div>
            </div>

            <div className="space-y-2">
              {analytics.engagementData.map((data: any, index: number) => (
                <div key={index} className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>{data.date}</span>
                    <span className="text-xs text-muted-foreground">
                      {data.likes + data.comments + data.shares} engagements
                    </span>
                  </div>
                  <div className="flex h-2 gap-0.5">
                    <div
                      className="bg-pink-500 rounded-l-full"
                      style={{ width: `${(data.likes / (data.likes + data.comments + data.shares)) * 100}%` }}
                    />
                    <div
                      className="bg-purple-500"
                      style={{ width: `${(data.comments / (data.likes + data.comments + data.shares)) * 100}%` }}
                    />
                    <div
                      className="bg-emerald-500 rounded-r-full"
                      style={{ width: `${(data.shares / (data.likes + data.comments + data.shares)) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-start gap-4 pt-2">
              <div className="flex items-center gap-1">
                <div className="h-3 w-3 rounded-full bg-pink-500" />
                <span className="text-xs">Likes</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="h-3 w-3 rounded-full bg-purple-500" />
                <span className="text-xs">Comments</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="h-3 w-3 rounded-full bg-emerald-500" />
                <span className="text-xs">Shares</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Top Performing Posts</CardTitle>
          <CardDescription>Your posts with the highest engagement</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {analytics.topPosts.map((post: any, index: number) => (
              <div key={index} className="flex items-center justify-between">
                <span className="font-medium">{post.title}</span>
                <div className="flex items-center gap-2">
                  <div className="h-2 bg-purple-500 rounded-full" style={{ width: `${post.engagement}px` }} />
                  <span className="text-sm">{post.engagement} engagements</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

