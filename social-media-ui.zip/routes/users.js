import express from "express"
import { asyncHandler } from "../utils/asyncHandler.js"
import { verifyToken, adminOnly, moderatorAndAbove } from "../middleware/auth.js"
import { upload } from "../utils/fileUpload.js"
import {
  getCurrentUser,
  getUserById,
  getUserByUsername,
  updateUser,
  deleteUser,
  followUser,
  unfollowUser,
  getFollowers,
  getFollowing,
  blockUser,
  unblockUser,
  getBlockedUsers,
  searchUsers,
  updateUserRole,
  getSuggestedUsers,
} from "../controllers/userController.js"

const router = express.Router()

// Public routes
router.get("/username/:username", asyncHandler(getUserByUsername))
router.get("/search", asyncHandler(searchUsers))

// Protected routes
router.use(verifyToken)
router.get("/me", asyncHandler(getCurrentUser))
router.get("/suggested", asyncHandler(getSuggestedUsers))
router.get("/:id", asyncHandler(getUserById))

// Configure multer for profile updates
const profileUpload = upload.fields([
  { name: "profilePicture", maxCount: 1 },
  { name: "coverPhoto", maxCount: 1 },
])
router.put("/me", profileUpload, asyncHandler(updateUser))
router.delete("/me", asyncHandler(deleteUser))

// Follow/Unfollow
router.post("/:id/follow", asyncHandler(followUser))
router.post("/:id/unfollow", asyncHandler(unfollowUser))

// Get followers/following
router.get("/:id/followers", asyncHandler(getFollowers))
router.get("/:id/following", asyncHandler(getFollowing))

// Block/Unblock
router.post("/:id/block", asyncHandler(blockUser))
router.post("/:id/unblock", asyncHandler(unblockUser))
router.get("/blocked", asyncHandler(getBlockedUsers))

// Admin routes
router.use(moderatorAndAbove)
router.put("/:id/role", adminOnly, asyncHandler(updateUserRole))

export default router

