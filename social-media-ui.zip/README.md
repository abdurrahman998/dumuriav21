# SocialSphere Backend

A secure and scalable backend for the SocialSphere social media application.

## Technologies Used

- **Firebase Authentication**: User authentication and management
- **MongoDB (Atlas)**: Database for storing user data, posts, comments, etc.
- **Express.js**: Web server framework
- **Socket.io**: Real-time communication for chat and notifications
- **Multer**: File upload and storage management

## Features

- **User Authentication**: Registration, login, OTP verification, password reset
- **User Profiles**: Create and update profiles, follow/unfollow users
- **Posts**: Create, read, update, delete posts with media uploads
- **Comments & Likes**: Interact with posts through comments and likes
- **Real-time Messaging**: Private and group messaging with typing indicators
- **Notifications**: Real-time notifications for interactions
- **Media Handling**: Upload and manage images, videos, and GIFs using Multer
- **Search**: Search for users, posts, and hashtags
- **Role-based Access Control**: User, moderator, and admin roles
- **Data Validation**: Input validation using Joi

## Getting Started

1. Clone the repository
2. Install dependencies: `npm install`
3. Create a `.env` file based on `.env.example`
4. Set up Firebase project for authentication
5. Set up MongoDB Atlas database
6. Run the server: `npm start` or `npm run dev` for development

## API Documentation

### Authentication Endpoints

- `POST /api/auth/register`: Register a new user
- `POST /api/auth/verify-otp`: Verify OTP for registration
- `POST /api/auth/login`: Login user
- `POST /api/auth/logout`: Logout user
- `POST /api/auth/forgot-password`: Request password reset
- `POST /api/auth/reset-password`: Reset password
- `POST /api/auth/change-password`: Change password (authenticated)

### User Endpoints

- `GET /api/users/me`: Get current user profile
- `GET /api/users/:id`: Get user by ID
- `GET /api/users/username/:username`: Get user by username
- `PUT /api/users/me`: Update current user profile
- `DELETE /api/users/me`: Delete current user account
- `POST /api/users/:id/follow`: Follow a user
- `POST /api/users/:id/unfollow`: Unfollow a user
- `GET /api/users/:id/followers`: Get user followers
- `GET /api/users/:id/following`: Get users being followed
- `POST /api/users/:id/block`: Block a user
- `POST /api/users/:id/unblock`: Unblock a user
- `GET /api/users/search`: Search for users

### Post Endpoints

- `POST /api/posts`: Create a new post
- `GET /api/posts/:id`: Get post by ID
- `PUT /api/posts/:id`: Update post
- `DELETE /api/posts/:id`: Delete post
- `POST /api/posts/:id/like`: Like a post
- `POST /api/posts/:id/unlike`: Unlike a post
- `GET /api/posts/feed`: Get feed posts
- `GET /api/posts/user/:userId`: Get user posts
- `POST /api/posts/:id/save`: Save a post
- `POST /api/posts/:id/unsave`: Unsave a post
- `GET /api/posts/saved`: Get saved posts
- `GET /api/posts/search`: Search posts
- `GET /api/posts/trending`: Get trending posts

### Comment Endpoints

- `POST /api/comments/post/:postId`: Create a comment
- `GET /api/comments/post/:postId`: Get post comments
- `GET /api/comments/:id`: Get comment by ID
- `PUT /api/comments/:id`: Update comment
- `DELETE /api/comments/:id`: Delete comment
- `POST /api/comments/:id/like`: Like a comment
- `POST /api/comments/:id/unlike`: Unlike a comment
- `GET /api/comments/:id/replies`: Get comment replies

### Message Endpoints

- `POST /api/messages/conversations`: Create a conversation
- `GET /api/messages/conversations`: Get user conversations
- `GET /api/messages/conversations/:id`: Get conversation by ID
- `POST /api/messages/conversations/:conversationId/messages`: Send a message
- `GET /api/messages/conversations/:conversationId/messages`: Get conversation messages
- `PUT /api/messages/:id`: Edit a message
- `DELETE /api/messages/:id`: Delete a message
- `POST /api/messages/:id/read`: Mark message as read
- `POST /api/messages/:id/reactions`: Add reaction to message

### Notification Endpoints

- `GET /api/notifications`: Get user notifications
- `GET /api/notifications/unread/count`: Get unread notifications count
- `PUT /api/notifications/:id/read`: Mark notification as read
- `PUT /api/notifications/read-all`: Mark all notifications as read

## Socket.io Events

### Client Events (Emit)

- `typing`: User is typing in a conversation
- `stopTyping`: User stopped typing
- `messageRead`: User read a message

### Server Events (Listen)

- `userTyping`: Someone is typing in a conversation
- `userStoppedTyping`: Someone stopped typing
- `newMessage`: New message received
- `messageReadUpdate`: Message read status updated
- `userStatus`: User online/offline status update
- `unreadCountUpdate`: Unread message count updated
- `conversationUpdate`: Conversation details updated

## File Storage

Files are stored locally using Multer with the following structure:
- `/uploads/posts`: Post media files
- `/uploads/profiles`: Profile pictures and cover photos
- `/uploads/messages`: Message attachments

## Security Features

- Firebase Authentication
- Password hashing
- Input validation with Joi
- Rate limiting
- CORS protection
- Helmet security headers
- Role-based access control

## License

MIT License

