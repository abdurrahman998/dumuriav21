"use client"

import Link from "next/link"
import { UserMenu } from "@/components/user-menu"
import { ThemeToggle } from "@/components/theme-toggle"
import { useRouter } from "next/navigation"
import { useState, useEffect } from "react"
import { getNotifications } from "@/lib/data"

export function MainNav() {
  const pathname = useRouter().pathname
  const router = useRouter()
  const [unreadNotifications, setUnreadNotifications] = useState(0)
  const [unreadMessages, setUnreadMessages] = useState(0)

  useEffect(() => {
    // Fetch notification count
    const fetchNotificationCount = async () => {
      try {
        const notifications = await getNotifications()
        const unreadCount = notifications.filter((n: any) => !n.isRead).length
        setUnreadNotifications(unreadCount)
      } catch (error) {
        console.error("Error fetching notifications:", error)
      }
    }

    fetchNotificationCount()

    // Mock unread messages count
    setUnreadMessages(3)

    // Reset notification count when visiting notifications page
    if (pathname === "/notifications") {
      setUnreadNotifications(0)
    }

    // Reset messages count when visiting messages page
    if (pathname.startsWith("/messages")) {
      setUnreadMessages(0)
    }
  }, [pathname])

  const handleSearch = (query: string) => {
    router.push(`/search?q=${encodeURIComponent(query)}`)
  }

  return (
    <div className="flex w-full items-center justify-between">
      <Link href="/feed" className="flex items-center space-x-2">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="h-6 w-6"
        >
          <path d="M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3" />
        </svg>
        <span className="hidden font-bold sm:inline-block">SocialSphere</span>
      </Link>
      <div className="flex items-center space-x-2">
        <ThemeToggle />
        <UserMenu />
      </div>
    </div>
  )
}

