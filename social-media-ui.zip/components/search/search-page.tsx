"use client"

import { useState, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { SearchBar } from "@/components/search/search-bar"
import { SearchResults } from "@/components/search/search-results"
import { SearchFilters } from "@/components/search/search-filters"
import { RecentSearches } from "@/components/search/recent-searches"
import { TrendingTopics } from "@/components/trending-topics"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { performSearch, getTrendingSearches, getRecentSearches } from "@/lib/search"

export function SearchPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const query = searchParams.get("q") || ""
  const category = searchParams.get("category") || "all"

  const [searchResults, setSearchResults] = useState<any>({
    users: [],
    posts: [],
    hashtags: [],
    groups: [],
  })
  const [isLoading, setIsLoading] = useState(false)
  const [recentSearches, setRecentSearches] = useState<string[]>([])
  const [trendingSearches, setTrendingSearches] = useState<any[]>([])

  // Fetch recent and trending searches on initial load
  useEffect(() => {
    const fetchInitialData = async () => {
      const recent = await getRecentSearches()
      const trending = await getTrendingSearches()

      setRecentSearches(recent)
      setTrendingSearches(trending)
    }

    fetchInitialData()
  }, [])

  // Perform search when query changes
  useEffect(() => {
    const fetchSearchResults = async () => {
      if (!query) {
        setSearchResults({
          users: [],
          posts: [],
          hashtags: [],
          groups: [],
        })
        return
      }

      setIsLoading(true)

      try {
        const results = await performSearch(query, category)
        setSearchResults(results)

        // Add to recent searches if not already there
        if (query && !recentSearches.includes(query)) {
          setRecentSearches((prev) => [query, ...prev.slice(0, 9)])
        }
      } catch (error) {
        console.error("Error performing search:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchSearchResults()
  }, [query, category])

  const handleSearch = (searchQuery: string) => {
    const params = new URLSearchParams(searchParams)

    if (searchQuery) {
      params.set("q", searchQuery)
    } else {
      params.delete("q")
    }

    router.push(`/search?${params.toString()}`)
  }

  const handleCategoryChange = (newCategory: string) => {
    const params = new URLSearchParams(searchParams)

    if (newCategory !== "all") {
      params.set("category", newCategory)
    } else {
      params.delete("category")
    }

    router.push(`/search?${params.toString()}`)
  }

  const handleClearRecentSearch = (searchQuery: string) => {
    setRecentSearches((prev) => prev.filter((item) => item !== searchQuery))
  }

  const handleClearAllRecentSearches = () => {
    setRecentSearches([])
  }

  return (
    <div className="space-y-6">
      <div className="sticky top-14 z-10 bg-background/95 pb-4 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <SearchBar initialQuery={query} onSearch={handleSearch} showVoiceSearch showCategories />
      </div>

      {query ? (
        <div className="grid gap-6 md:grid-cols-[280px_1fr]">
          <div className="hidden md:block">
            <SearchFilters activeCategory={category} onCategoryChange={handleCategoryChange} />
          </div>
          <div>
            <Tabs defaultValue={category === "all" ? "all" : category} onValueChange={handleCategoryChange}>
              <div className="md:hidden">
                <TabsList className="w-full justify-start overflow-auto">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="users">People</TabsTrigger>
                  <TabsTrigger value="posts">Posts</TabsTrigger>
                  <TabsTrigger value="hashtags">Hashtags</TabsTrigger>
                  <TabsTrigger value="groups">Groups</TabsTrigger>
                </TabsList>
              </div>

              <TabsContent value="all">
                <SearchResults results={searchResults} isLoading={isLoading} query={query} showAllCategories />
              </TabsContent>

              <TabsContent value="users">
                <SearchResults results={{ users: searchResults.users }} isLoading={isLoading} query={query} />
              </TabsContent>

              <TabsContent value="posts">
                <SearchResults results={{ posts: searchResults.posts }} isLoading={isLoading} query={query} />
              </TabsContent>

              <TabsContent value="hashtags">
                <SearchResults results={{ hashtags: searchResults.hashtags }} isLoading={isLoading} query={query} />
              </TabsContent>

              <TabsContent value="groups">
                <SearchResults results={{ groups: searchResults.groups }} isLoading={isLoading} query={query} />
              </TabsContent>
            </Tabs>
          </div>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-[2fr_1fr]">
          <div className="space-y-6">
            <RecentSearches
              searches={recentSearches}
              onSearchClick={handleSearch}
              onClearSearch={handleClearRecentSearch}
              onClearAll={handleClearAllRecentSearches}
            />

            <div className="rounded-lg border p-4">
              <h2 className="mb-4 text-lg font-semibold">Discover People</h2>
              {/* User suggestions would go here */}
              <p className="text-center text-muted-foreground">Start searching to find people to follow</p>
            </div>
          </div>

          <div className="space-y-6">
            <TrendingTopics searchable onTagClick={handleSearch} />
          </div>
        </div>
      )}
    </div>
  )
}

