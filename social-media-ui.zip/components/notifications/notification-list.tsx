"use client"

import { cn } from "@/lib/utils"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { formatDistanceToNow } from "date-fns"
import { Heart, MessageCircle, Repeat, UserPlus, MoreHorizontal, Check, Bell } from "lucide-react"
import { Icons } from "@/components/icons"
import { getNotifications } from "@/lib/data"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"

export function NotificationList() {
  const [notifications, setNotifications] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedNotifications, setSelectedNotifications] = useState<string[]>([])
  const [selectMode, setSelectMode] = useState(false)

  useEffect(() => {
    const fetchNotifications = async () => {
      setLoading(true)
      try {
        const data = await getNotifications()
        setNotifications(data)
      } catch (error) {
        console.error("Error fetching notifications:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchNotifications()
  }, [])

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "like":
        return <Heart className="h-5 w-5 text-red-500" />
      case "comment":
        return <MessageCircle className="h-5 w-5 text-blue-500" />
      case "repost":
        return <Repeat className="h-5 w-5 text-green-500" />
      case "follow":
        return <UserPlus className="h-5 w-5 text-purple-500" />
      default:
        return null
    }
  }

  const getNotificationText = (notification: any) => {
    switch (notification.type) {
      case "like":
        return (
          <>
            <span className="font-semibold">{notification.actor.name}</span> liked your post
          </>
        )
      case "comment":
        return (
          <>
            <span className="font-semibold">{notification.actor.name}</span> commented on your post
          </>
        )
      case "repost":
        return (
          <>
            <span className="font-semibold">{notification.actor.name}</span> reposted your post
          </>
        )
      case "follow":
        return (
          <>
            <span className="font-semibold">{notification.actor.name}</span> followed you
          </>
        )
      default:
        return null
    }
  }

  const toggleNotificationRead = (id: string) => {
    setNotifications(
      notifications.map((notification) =>
        notification.id === id ? { ...notification, isRead: !notification.isRead } : notification,
      ),
    )
  }

  const markAllAsRead = () => {
    setNotifications(notifications.map((notification) => ({ ...notification, isRead: true })))
  }

  const toggleSelectNotification = (id: string) => {
    if (selectedNotifications.includes(id)) {
      setSelectedNotifications(selectedNotifications.filter((notifId) => notifId !== id))
    } else {
      setSelectedNotifications([...selectedNotifications, id])
    }
  }

  const toggleSelectMode = () => {
    setSelectMode(!selectMode)
    setSelectedNotifications([])
  }

  const markSelectedAsRead = () => {
    setNotifications(
      notifications.map((notification) =>
        selectedNotifications.includes(notification.id) ? { ...notification, isRead: true } : notification,
      ),
    )
    setSelectedNotifications([])
    setSelectMode(false)
  }

  const markSelectedAsUnread = () => {
    setNotifications(
      notifications.map((notification) =>
        selectedNotifications.includes(notification.id) ? { ...notification, isRead: false } : notification,
      ),
    )
    setSelectedNotifications([])
    setSelectMode(false)
  }

  const deleteSelected = () => {
    setNotifications(notifications.filter((notification) => !selectedNotifications.includes(notification.id)))
    setSelectedNotifications([])
    setSelectMode(false)
  }

  const allNotifications = notifications
  const mentionsNotifications = notifications.filter((n) => n.type === "comment" && n.isMention)
  const unreadCount = notifications.filter((n) => !n.isRead).length

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Notifications</h1>
        <div className="flex items-center space-x-2">
          {unreadCount > 0 && (
            <Button variant="outline" size="sm" onClick={markAllAsRead}>
              <Check className="mr-2 h-4 w-4" />
              Mark all as read
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={toggleSelectMode}>
            {selectMode ? "Cancel" : "Select"}
          </Button>
          {selectMode && selectedNotifications.length > 0 && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm">
                  Actions <MoreHorizontal className="ml-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={markSelectedAsRead}>
                  <Check className="mr-2 h-4 w-4" />
                  Mark as read
                </DropdownMenuItem>
                <DropdownMenuItem onClick={markSelectedAsUnread}>
                  <Bell className="mr-2 h-4 w-4" />
                  Mark as unread
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={deleteSelected} className="text-red-500 focus:text-red-500">
                  <Icons.trash className="mr-2 h-4 w-4" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="mentions">Mentions</TabsTrigger>
          <TabsTrigger value="unread">
            Unread
            {unreadCount > 0 && (
              <span className="ml-1 rounded-full bg-primary px-1.5 py-0.5 text-xs text-primary-foreground">
                {unreadCount}
              </span>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          {loading ? (
            <div className="flex justify-center p-8">
              <Icons.spinner className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : allNotifications.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No notifications yet</p>
            </Card>
          ) : (
            allNotifications.map((notification) => (
              <Card
                key={notification.id}
                className={cn(
                  "p-4 transition-colors",
                  !notification.isRead && "bg-muted/40 dark:bg-muted/20",
                  selectMode && selectedNotifications.includes(notification.id) && "border-primary",
                )}
              >
                <div className="flex items-start space-x-4">
                  {selectMode && (
                    <div className="mt-2">
                      <input
                        type="checkbox"
                        checked={selectedNotifications.includes(notification.id)}
                        onChange={() => toggleSelectNotification(notification.id)}
                        className="h-4 w-4 rounded border-gray-300"
                      />
                    </div>
                  )}

                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted">
                    {getNotificationIcon(notification.type)}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm">{getNotificationText(notification)}</p>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(notification.timestamp), { addSuffix: true })}
                        </span>

                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">More options</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => toggleNotificationRead(notification.id)}>
                              {notification.isRead ? (
                                <>
                                  <Bell className="mr-2 h-4 w-4" />
                                  Mark as unread
                                </>
                              ) : (
                                <>
                                  <Check className="mr-2 h-4 w-4" />
                                  Mark as read
                                </>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-500 focus:text-red-500">
                              <Icons.trash className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>

                    {notification.content && (
                      <p className="mt-1 text-sm text-muted-foreground">{notification.content}</p>
                    )}

                    {notification.type === "follow" && (
                      <div className="mt-2">
                        <Button variant="outline" size="sm" className="h-8" asChild>
                          <Link href={`/profile/${notification.actor.username}`}>View Profile</Link>
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="mentions" className="space-y-4">
          {loading ? (
            <div className="flex justify-center p-8">
              <Icons.spinner className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : mentionsNotifications.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No mentions yet</p>
            </Card>
          ) : (
            mentionsNotifications.map((notification) => (
              <Card
                key={notification.id}
                className={cn(
                  "p-4 transition-colors",
                  !notification.isRead && "bg-muted/40 dark:bg-muted/20",
                  selectMode && selectedNotifications.includes(notification.id) && "border-primary",
                )}
              >
                <div className="flex items-start space-x-4">
                  {selectMode && (
                    <div className="mt-2">
                      <input
                        type="checkbox"
                        checked={selectedNotifications.includes(notification.id)}
                        onChange={() => toggleSelectNotification(notification.id)}
                        className="h-4 w-4 rounded border-gray-300"
                      />
                    </div>
                  )}

                  <Avatar>
                    <AvatarImage src={notification.actor.avatar} alt={notification.actor.name} />
                    <AvatarFallback>{notification.actor.name.charAt(0)}</AvatarFallback>
                  </Avatar>

                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm">
                        <span className="font-semibold">{notification.actor.name}</span> mentioned you in a comment
                      </p>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(notification.timestamp), { addSuffix: true })}
                        </span>

                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">More options</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => toggleNotificationRead(notification.id)}>
                              {notification.isRead ? (
                                <>
                                  <Bell className="mr-2 h-4 w-4" />
                                  Mark as unread
                                </>
                              ) : (
                                <>
                                  <Check className="mr-2 h-4 w-4" />
                                  Mark as read
                                </>
                              )}
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-500 focus:text-red-500">
                              <Icons.trash className="mr-2 h-4 w-4" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>

                    <p className="mt-1 text-sm text-muted-foreground">{notification.content}</p>

                    <div className="mt-2">
                      <Button variant="outline" size="sm" className="h-8" asChild>
                        <Link href={`/post/${notification.postId}`}>View Post</Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="unread" className="space-y-4">
          {loading ? (
            <div className="flex justify-center p-8">
              <Icons.spinner className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : notifications.filter((n) => !n.isRead).length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No unread notifications</p>
            </Card>
          ) : (
            notifications
              .filter((n) => !n.isRead)
              .map((notification) => (
                <Card
                  key={notification.id}
                  className={cn(
                    "p-4 transition-colors bg-muted/40 dark:bg-muted/20",
                    selectMode && selectedNotifications.includes(notification.id) && "border-primary",
                  )}
                >
                  <div className="flex items-start space-x-4">
                    {selectMode && (
                      <div className="mt-2">
                        <input
                          type="checkbox"
                          checked={selectedNotifications.includes(notification.id)}
                          onChange={() => toggleSelectNotification(notification.id)}
                          className="h-4 w-4 rounded border-gray-300"
                        />
                      </div>
                    )}

                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted">
                      {getNotificationIcon(notification.type)}
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="text-sm">{getNotificationText(notification)}</p>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs text-muted-foreground">
                            {formatDistanceToNow(new Date(notification.timestamp), { addSuffix: true })}
                          </span>

                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 rounded-full"
                            onClick={() => toggleNotificationRead(notification.id)}
                          >
                            <Check className="h-4 w-4" />
                            <span className="sr-only">Mark as read</span>
                          </Button>
                        </div>
                      </div>

                      {notification.content && (
                        <p className="mt-1 text-sm text-muted-foreground">{notification.content}</p>
                      )}

                      {notification.type === "follow" && (
                        <div className="mt-2">
                          <Button variant="outline" size="sm" className="h-8" asChild>
                            <Link href={`/profile/${notification.actor.username}`}>View Profile</Link>
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </Card>
              ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

