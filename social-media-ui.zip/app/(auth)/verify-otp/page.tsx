"use client"

import { useState, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/lib/auth"
import { Loader2 } from "lucide-react"

export default function VerifyOTPPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const { toast } = useToast()
  const { verifyOTP, resendOTP } = useAuth()

  const [email, setEmail] = useState<string>("")
  const [otp, setOtp] = useState<string>("")
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [isResending, setIsResending] = useState<boolean>(false)
  const [countdown, setCountdown] = useState<number>(0)

  useEffect(() => {
    const emailParam = searchParams.get("email")
    if (!emailParam) {
      toast({
        title: "Error",
        description: "Email parameter is missing",
        variant: "destructive",
      })
      router.push("/register")
      return
    }
    setEmail(emailParam)
  }, [searchParams, router, toast])

  useEffect(() => {
    let timer: NodeJS.Timeout
    if (countdown > 0) {
      timer = setTimeout(() => setCountdown(countdown - 1), 1000)
    }
    return () => clearTimeout(timer)
  }, [countdown])

  const handleVerify = async () => {
    if (!otp || otp.length !== 6) {
      toast({
        title: "Error",
        description: "Please enter a valid 6-digit OTP",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      await verifyOTP(email, otp)
      toast({
        title: "Success",
        description: "Your account has been verified successfully",
      })
      // Redirect will be handled by the auth context
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to verify OTP. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleResend = async () => {
    setIsResending(true)
    try {
      await resendOTP(email)
      toast({
        title: "Success",
        description: "A new verification code has been sent to your email",
      })
      setCountdown(60) // Start 60 second countdown
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to resend OTP. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsResending(false)
    }
  }

  return (
    <div className="container flex h-screen w-screen flex-col items-center justify-center">
      <Card className="w-full max-w-md mx-auto shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Verify Your Email</CardTitle>
          <CardDescription>We've sent a verification code to {email}. Please enter the code below.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label
              htmlFor="otp"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Verification Code
            </label>
            <Input
              id="otp"
              placeholder="Enter 6-digit code"
              value={otp}
              onChange={(e) => setOtp(e.target.value.replace(/[^0-9]/g, "").slice(0, 6))}
              className="text-center text-lg tracking-widest"
              maxLength={6}
            />
          </div>
          <Button onClick={handleVerify} className="w-full" disabled={isLoading || otp.length !== 6}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Verifying...
              </>
            ) : (
              "Verify Email"
            )}
          </Button>
        </CardContent>
        <CardFooter className="flex flex-col items-center gap-2">
          <p className="text-sm text-muted-foreground">Didn't receive a code?</p>
          <Button variant="ghost" onClick={handleResend} disabled={isResending || countdown > 0}>
            {countdown > 0 ? (
              `Resend code in ${countdown}s`
            ) : isResending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Sending...
              </>
            ) : (
              "Resend Code"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

