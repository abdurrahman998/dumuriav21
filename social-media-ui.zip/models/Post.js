import mongoose from "mongoose"

const PostSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    content: {
      type: String,
      required: true,
      maxlength: 5000,
    },
    media: [
      {
        type: {
          type: String,
          enum: ["image", "video", "gif"],
          required: true,
        },
        url: {
          type: String,
          required: true,
        },
        alt: String,
      },
    ],
    likes: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    comments: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Comment",
      },
    ],
    tags: [
      {
        type: String,
        trim: true,
      },
    ],
    location: {
      name: String,
      coordinates: {
        latitude: Number,
        longitude: Number,
      },
    },
    isEdited: {
      type: Boolean,
      default: false,
    },
    isPinned: {
      type: Boolean,
      default: false,
    },
    visibility: {
      type: String,
      enum: ["public", "followers", "private"],
      default: "public",
    },
    poll: {
      question: String,
      options: [
        {
          text: String,
          votes: [
            {
              type: mongoose.Schema.Types.ObjectId,
              ref: "User",
            },
          ],
        },
      ],
      expiresAt: Date,
    },
    mentions: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        startIndex: Number,
        endIndex: Number,
      },
    ],
  },
  { timestamps: true },
)

// Virtual for post's full URL
PostSchema.virtual("url").get(function () {
  return `/post/${this._id}`
})

// Method to check if post has media
PostSchema.virtual("hasMedia").get(function () {
  return this.media && this.media.length > 0
})

// Method to check if post has poll
PostSchema.virtual("hasPoll").get(function () {
  return this.poll && this.poll.question
})

// Method to get total likes count
PostSchema.virtual("likesCount").get(function () {
  return this.likes.length
})

// Method to get total comments count
PostSchema.virtual("commentsCount").get(function () {
  return this.comments.length
})

// Index for text search
PostSchema.index({ content: "text", tags: "text" })

const Post = mongoose.model("Post", PostSchema)

export default Post

